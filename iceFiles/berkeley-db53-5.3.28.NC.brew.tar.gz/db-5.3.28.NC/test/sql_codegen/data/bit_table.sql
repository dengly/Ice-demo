
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_bit BIT PRIMARY KEY);