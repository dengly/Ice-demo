
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_bigint BIGINT PRIMARY KEY);