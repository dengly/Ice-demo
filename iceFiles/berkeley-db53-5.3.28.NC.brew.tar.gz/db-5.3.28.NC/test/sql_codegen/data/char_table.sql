
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_char CHAR(20) PRIMARY KEY);