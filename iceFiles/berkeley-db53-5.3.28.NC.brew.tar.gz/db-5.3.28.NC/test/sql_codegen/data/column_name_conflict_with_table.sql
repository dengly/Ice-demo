CREATE DATABASE numismatics;  

CREATE TABLE coin (coin INT(8) PRIMARY KEY,
                       unit VARCHAR(20));