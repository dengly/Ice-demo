
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_decimal DECIMAL PRIMARY KEY);