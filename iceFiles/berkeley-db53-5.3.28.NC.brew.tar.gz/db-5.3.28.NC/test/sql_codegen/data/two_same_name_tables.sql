CREATE DATABASE numismatics;

CREATE TABLE coin (cid INT(8) PRIMARY KEY,
                       unit VARCHAR(20));

CREATE TABLE coin (mid INT(8) PRIMARY KEY,
       country VARCHAR(20),
       city VARCHAR(20));
