CREATE TABLE coin (cid INT(8) PRIMARY KEY,
                       unit VARCHAR(20));

CREATE TABLE mint (mid INT(8),
       country VARCHAR(20),
       city VARCHAR(20));