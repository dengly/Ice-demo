
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_int INT(8) PRIMARY KEY,
			att_char CHAR(2));