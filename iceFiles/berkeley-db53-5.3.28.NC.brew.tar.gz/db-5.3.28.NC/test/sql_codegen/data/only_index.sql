
CREATE INDEX unit_index ON coin(unit);

