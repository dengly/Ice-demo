/*-
 * See the file LICENSE for redistribution information.
 * 
 * Copyright (c) 2010, 2013 Oracle and/or its affiliates.  All rights reserved.
 *
 */

package repmgrtests;

public class MyStats {
    public long permFailedCount;
    public long egen;
    public long elections;
    public long envId;
    public long master;
}
